function Card(point, suit){
  this.point = point;
  this.suit = suit;
}

Card.prototype.getImageUrl = function(){
  if (this.point === 11){
    console.log(this.point);
    return "images/jack_of_" + this.suit + ".png";
  }
  else if (this.point === 12){
    return "images/queen_of_" + this.suit + ".png";
  }
  else if (this.point === 13){
    return "images/king_of_" + this.suit + ".png";
  }
  else if (this.point === 1){
    return "images/ace_of_" + this.suit + ".png";
  }
  else{
  return "images/" + this.point + "_of_" + this.suit + ".png";
}
};

function Hand(){
  this.cards = [];
}

Hand.prototype.addCard = function(card){
  this.cards.push(card);
};

Hand.prototype.getPoints = function(){
var sum = 0;
var have_eleven = false;
for (i=0; i < this.cards.length; i++){
  if (this.cards[i].point === 1){

      if (sum > 10){
        sum += 1;

      }

    else{
    sum += 11;
    have_eleven = true;
  }
}
  if (this.cards[i].point > 10) {
    sum += 10;
  }
  else if(this.cards[i].point > 1 && this.cards[i].point <= 10 ){
  sum += this.cards[i].point;
  }
}
if (have_eleven){
  if (sum > 21){
    sum -= 10;
  }
}

return sum;
};


function Deck(){
  this.cards = [];
  for (i=1; i<14; i++) {
    this.cards.push(new Card(i,'spades'));
    this.cards.push(new Card(i,'hearts'));
    this.cards.push(new Card(i,'clubs'));
    this.cards.push(new Card(i,'diamonds'));
  }
}

Deck.prototype.draw = function(){
  return this.cards.pop();
};

Deck.prototype.numCardsLeft = function(){
  return this.cards.length;
};


Deck.prototype.shuffle = function(){
  var m = this.cards.length, t, i;

  // While there remain elements to shuffle…
  while (m) {

    // Pick a remaining element…
    i = Math.floor(Math.random() * m--);

    // And swap it with the current element.
    t = this.cards[m];
    this.cards[m] = this.cards[i];
    this.cards[i] = t;
  }

  return this.cards;
  // this.cards.map(function(place){
  // var new_place = Math.floor(Math.random() * place);
  // this.cards[new_place] = this.cards[place];
}



// Beginning of V1 CODE


getCardImageUrl = function(card){
   if (card.point > 1 && card.point <= 10) {
      return 'images/' + card.point + '_of_' + card.suit + '.png';
   }
   else if (card.point === 11) {
     return 'images/jack_of_' + card.suit + '.png';
   }
   else if (card.point === 12) {
     return 'images/queen_of_' + card.suit + '.png';
   }
   else if (card.point === 13) {
     return 'images/king_of_' + card.suit + '.png';
   }

    else {
      return 'images/ace_of_' + card.suit + '.png';
    }
};

var deck = new Deck();
var winnings = 500;
var dealerHand = new Hand();
var playerHand = new Hand();
var d_points = 0;
var p_points = 0;
var d_wins = 0;
var p_wins = 0;
var hidden_image_url;
var bet_amount = 0;
var win_amount = 0;

$('#score').hide();
$('#hit-button').hide();
$('#stand-button').hide();
$('#winnings').text("$"+winnings);
var random;
$('#reset-button').hide();
$("#current_bet_row").hide();

dealer_deal = function(){
  var deal = deck.cards.pop();
  console.log("Deal a card off the end of deck: " + deal.getImageUrl());
  image_url = deal.getImageUrl();
  $('#dealer-hand').append('<img class = "animated slideInLeft" src="' + image_url + '"/>');
  dealerHand.addCard(deal);

};

dealer_hide_deal = function(){

  var deal = deck.cards.pop();
  hidden_image_url = deal.getImageUrl();
  $('#dealer-hand').append('<img id = "hidden_card" class = "animated slideInLeft" src="images/pokemon_back.png"/>');
  dealerHand.addCard(deal);

};

player_deal = function(){

  var deal = deck.cards.pop();
  image_url = deal.getImageUrl();
  $('#player-hand').append('<img class = "animated slideInLeft" src="' + image_url + '"/>');
  playerHand.addCard(deal);
  console.log("deck length: " + deck.cards.length);
};


$(function() {

  $('#deal-button').click(function() {
    deck.shuffle();
    dealer_deal();
    dealer_hide_deal();
    player_deal();
    player_deal();
    d_points = dealerHand.getPoints();
    p_points = playerHand.getPoints();
    $("#player-points").text(p_points);
    $("#deal-button").hide();
    $('#hit-button').show();
    $('#stand-button').show();
    bet_amount = Number($("#bet_box").val());
    $("#current_bet_row").show();
    $("#current_bet").text("$"+ bet_amount);
    console.log("Bet amount:" + bet_amount);
    winnings -= bet_amount;
    $("#bet_box").hide();
    $("#winnings").text("$" + winnings);
  });

  $('#hit-button').click(function() {
    player_deal();
    var p_points = playerHand.getPoints();
    $("#player-points").text(p_points);

    if (p_points > 21) {
      console.log("Player busts");
      $("#player-points").text(p_points + ": Bust!");

        $("#hit-button").hide();
        $('#reset-button').show();
        $('#stand-button').hide();
        d_wins += 1;
    }
  });

  $('#stand-button').click(function(){
    p_points = $("#player-points").text();
    $("#dealer-points").text(d_points);
    $("#hidden_card").attr("src", hidden_image_url);
    $("#hit-button").hide();
    var d_points = dealerHand.getPoints();
    while (d_points <= 17){
      dealer_deal();
      d_points = dealerHand.getPoints();
      $("#dealer-points").text(d_points);
    }
    if (d_points > 21) {
      console.log("Dealer busts");
      $("#dealer-points").text(d_points + ": Bust!");
      $("#player-points").text(p_points + ": Player Wins!!");
      p_wins += 1;
      winnings += bet_amount * 2;
      $("#winnings").text("$" + winnings);

    }
    else{
      if (d_points > p_points){
        $("#dealer-points").text(d_points + ": Dealer Wins!!");
        d_wins += 1;

      }
      else if (d_points < p_points){
        $("#player-points").text(p_points + ": Player Wins!!");
        p_wins += 1;
        winnings += bet_amount * 2;
          $("#winnings").text("$" + winnings);
      }
      else {
        $("#player-points").text(p_points + ": Draw!!");
        $("#dealer-points").text(d_points + ": Draw!!");
        winnings += bet_amount;
          $("#winnings").text("$" + winnings);
      }
    }
    $('#reset-button').show();
    $('#stand-button').hide();
  });

  $('#reset-button').click(function() {
    deck = new Deck();
    $("#deal-button").show();
    $("#player-points").text('');
    $("#dealer-points").text('');
    $("#dealer-hand > img").remove();
    $("#player-hand > img").remove();
    d_points = 0;
    p_points = 0;
    dealerHand = new Hand();
    playerHand = new Hand();
    $("#player-wins").text(p_wins);
    $("#dealer-wins").text(d_wins);
    $("#score").show();
      $('#reset-button').hide();
    $("#bet_table").css("margin-top", "30px");
    $("#bet_box").val('').show();
    $("#current_bet_row").hide();
  });

});
// console.log(calculatePoints([{point: 1, suit: 'spades'},{point: 10, suit: 'spades'},{point: 2, suit: 'spades'}, {point: 1, suit: 'spades'}]));
